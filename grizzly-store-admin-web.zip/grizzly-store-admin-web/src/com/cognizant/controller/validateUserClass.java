package com.cognizant.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class validateUserClass {
	public static boolean validate(String username,String password){  
		boolean status=false;  

		try {
			Class.forName("oracle.jdbc.OracleDriver");
		}	 catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
			e.printStackTrace();
			}
try
{
		Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:xe","system","cognizant");
	PreparedStatement statement=connection.prepareStatement("select * from GRIZZLYSTORE where USERNAME=? and PASSWORD=?");
	statement.setString(1, username);
	statement.setString(2, password);
	ResultSet resultSet=statement.executeQuery(); 
		status=resultSet.next();  
		}
catch(Exception e)
		{
			System.out.println(e);
			}  
	return status;  
		}  

}
